package com.quinbay.wholesaler.modal;

import javax.persistence.Column;

public class WarehouseStock{
    public int id;
    public int warehouseid;
    public int productid;
    public int stock;
    public int price;
}

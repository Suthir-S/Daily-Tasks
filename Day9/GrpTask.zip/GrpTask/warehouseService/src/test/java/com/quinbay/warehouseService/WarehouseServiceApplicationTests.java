package com.quinbay.warehouseService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

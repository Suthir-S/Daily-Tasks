package com.quinbay.retailerService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
